<?php
// Database configuration
$servername = "localhost";
$username = "root";  // Use your MySQL username
$password = "";      // Use your MySQL password
$dbname = "search_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get search query from URL
$query = isset($_GET['query']) ? $_GET['query'] : '';

// SQL query to search blog posts
$sql = "SELECT title, content FROM posts WHERE title LIKE ? OR content LIKE ?";
$stmt = $conn->prepare($sql);
$searchQuery = '%' . $query . '%';
$stmt->bind_param('ss', $searchQuery, $searchQuery);
$stmt->execute();
$result = $stmt->get_result();

$blogs = [];
while ($row = $result->fetch_assoc()) {
    $blogs[] = $row;
}

// Output as JSON
header('Content-Type: application/json');
echo json_encode($blogs);

$stmt->close();
$conn->close();
?>
